<?php
DEFINE ('DB USER', 'root');
DEFINE ('DB PSWD', '');
DEFINE ('DB HOST', 'localhost');
DEFINE ('DB NAME', 'pat');


$dbcon = mysql_connect(DB_HOST, DB_USER, DB_PSWD, DB_NAME);

?>
