<?php
mysql_connect('localhost','root','') or die("not connected");
mysql_select_db("student") or die("no db found");

if(isset($_POST['submit'])){
$name=$_POST['name'];
$mail=$_POST['mail'];
$age=$_POST['age"'];
$gender=$_POST['gender'];
$symptoms=$_POST['symptoms'];

$query = "INSERT INTO test (name,mail,age,gender,symptoms) VALUES ('$name','$mail','$age','$gender','$symptoms')";
if(!mysql_query($query))
{
	echo 'INSERTED';
}
}

?>
