<?php
if (isset($_POST['submitted'])){
include('connect.php')
$name = $_POST['name'];
$mail = $_POST['mail'];
$age = $_POST['age"'];
$gender = $_POST['gender'];
$symptoms = $_POST['symptoms'];
$query = "SELECT * FROM test WHERE $disease LIKE '$symptoms'";
$result = mysql_query($dbcon, $query) or die('error getting data');

echo "<table>"
echo "<tr> <th>disease</th><th>tablets</th><th>symptoms</th><th>store</th></tr>"
while ($row = mysql_fetch_array($result, MYSQLI_ASSOC))
echo "<tr><td>";
echo $row['disese'];
echo "<td><td>";
echo $row['tablet'];
echo "<tr><td>";
echo $row['symptoms'];
echo "<td><td>";
echo $row['store'];
echo "</td></tr>";




echo"</table>"
}
?>

</body>
</html>


</BODY>
</HTML>